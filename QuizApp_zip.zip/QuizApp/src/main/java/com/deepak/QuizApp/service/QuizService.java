package com.deepak.QuizApp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.deepak.QuizApp.doa.QuestionDao;
import com.deepak.QuizApp.doa.QuizDao;
import com.deepak.QuizApp.models.Question;
import com.deepak.QuizApp.models.QuestionWrapper;
import com.deepak.QuizApp.models.Quiz;
import com.deepak.QuizApp.models.Response;

@Service
public class QuizService {

    @Autowired
    private QuizDao quizDoa;
    @Autowired
    private QuestionDao questionDao;

    public ResponseEntity<String> createQuiz(String category, int noOfQuestions, String quizTitle) {
        Quiz quiz = new Quiz();
        quiz.setTitle(quizTitle);
        List<Question> questions = questionDao.findRandomQuestionsByCategory(category, noOfQuestions);
        quiz.setQuestions(questions);
        quizDoa.save(quiz);
        return new ResponseEntity<>("Quiz creation sucessfull", HttpStatus.CREATED);
    }

    public ResponseEntity<List<QuestionWrapper>> getQuizQuestions(int id) {
        Optional<Quiz> quiz = quizDoa.findById(id);
        List<Question> questionsFromDB = quiz.get().getQuestions();
        List<QuestionWrapper> questionsForUser = new ArrayList<>();
        for (Question question : questionsFromDB)
            questionsForUser.add(new QuestionWrapper(question.getId(), question.getOption1(), question.getOption2(),
                    question.getOption3(), question.getOption4(), question.getQuestionTitle()));
        return new ResponseEntity<>(questionsForUser, HttpStatus.OK);
    }

    public ResponseEntity<Integer> calculateScore(int id, List<Response> responses) {
        Optional<Quiz> quiz = quizDoa.findById(id);
        List<Question> questions = quiz.get().getQuestions();
        Integer score = 0;
        for (int i = 0; i < responses.size(); i++) {
            if (responses.get(i).getResponse().equals(questions.get(i).getRightAnswer()))
                score += 1;
        }
        return new ResponseEntity<>(score, HttpStatus.OK);
    }
}

