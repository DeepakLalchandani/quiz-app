package com.deepak.QuizApp.doa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.deepak.QuizApp.models.Quiz;

public interface QuizDao extends JpaRepository<Quiz, Integer> {

}
